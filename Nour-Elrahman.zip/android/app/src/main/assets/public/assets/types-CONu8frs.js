var r=(a=>(a.Cash="نقدا",a.Credit="آجل",a.VodafoneCash="فودافون كاش",a.Instapay="انستا باي",a))(r||{}),s=(a=>(a.Admin="admin",a.Cashier="cashier",a))(s||{});export{r as P,s as U};
